const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const {
  PutCommand,
  DynamoDBDocumentClient,
  UpdateCommand,
  DeleteCommand,
} = require("@aws-sdk/lib-dynamodb");
const createExpressionConfig = require("./createExpressionConfig");
const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);

const test = async (eventName, tableName, model) => {
  //   const { eventName, tableName, model } = event;
  let command;

  switch (eventName) {
    case "create":
      command = new PutCommand({
        TableName: tableName,
        Item: model,
      });
      break;
    case "update":
      command = new UpdateCommand({
        TableName: tableName,
        Key: {
          id: model.id,
        },
        ...createExpressionConfig(tableName, model),
        ReturnValues: "ALL_NEW",
      });
      break;
    case "delete":
      command = new DeleteCommand({
        TableName: tableName,
        Key: {
          id: model,
        },
      });
      break;
    default:
      // TODO: return status code here
      command = null;
      break;
  }

  try {
    const response = await docClient.send(command);

    return {
      statusCode: 200,
      body: JSON.stringify({
        data: command,
      }),
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ message: "Internal Server Error" }),
    };
  }
};

console.log(
  test("create", "matches", {
    awayTeam: "905b4d32-ee84-4d1d-8d88-2d14416cf333",
    date: "2024-01-30",
    homeTeam: "905b4d32-ee84-4d1d-8d88-2d14416cfab9",
    id: "6ae6b7c1-d58f-44d0-9bc8-fff0dsdslxx",
    leagueId: "905b4d32-ee84-4d1d-8d88-2d14416c0000",
    location: "Binghamton, NY, USA",
    name: "Casey like eggs",
    officiating: [
      "sdkjfbyuig237932ddds",
      "sadjcyb126w3333512ds",
      "mcuewhy39fbc82bc89ns",
    ],
    seasonId: "e7964932-7c15-4960-a059-941544f6ac19",
    time: "7:35:14 PM",
  })
);
